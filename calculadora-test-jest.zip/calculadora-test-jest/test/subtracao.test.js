const fnSubtracao = require("../javascript/subtracao");

test("Subtracao de 10 - - 1000 é igual a 1010", () => {
    expect(fnSubtracao(10, -1000)).toBe(1010)
})

test("Subtração de 8827 - -2576 é igual a 6251", () => {
    expect(fnSubtracao(8827, -2576)).toBe(11403)
})

test("Subtração de 5769 - -10 é igual a 5759", () => {
    expect(fnSubtracao(5769, -10)).toBe(5779)
})

test("Subtração de 1000 - 9999 é igual a - 8999", () => {
    expect(fnSubtracao(1000, 9999)).toBe(-8999)
})