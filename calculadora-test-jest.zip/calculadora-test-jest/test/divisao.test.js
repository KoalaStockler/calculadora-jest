const fnDividir = require("../javascript/divisao");

test("A divisão de 10 por 5 é igual a 2", () => {
    expect(fnDividir(10, 5)).toBe(2)
})

test("A divisão de 5000 por 1000 é igual a 5", () => {
    expect(fnDividir(5000, 1000)).toBe(5)
})

test("A divisão de 40 por 0.5 é igual a 20", () => {
    expect(fnDividir(40, 0.5)).toBe(80)
})

test("A divisão de 50 por 50 é igual a 1", () => {
    expect(fnDividir(50, 50)).toBe(1)
})