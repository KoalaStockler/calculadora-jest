const fnSoma = require("../javascript/soma");

test("Soma de 1 + 2 é igual a 3", () => {
    expect(fnSoma(8827, -2576)).toBe(6251);
});

test("Some de 0 + 9 é igual a -9", () => {
    expect(fnSoma(0, -9)).toBe(-9)
})

test("Soma de -1 + -90 é igual a -91", () => {
    expect(fnSoma(-1, -90)).toBe(-91)
})

test("Soma de -5 + -9 é igual a -14", () => {
    expect(fnSoma(-5, -9)).toBe(-14)
})