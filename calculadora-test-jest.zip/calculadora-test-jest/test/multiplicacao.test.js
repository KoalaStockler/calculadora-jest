const fnMultiplicar = require("../javascript/multiplicacao");

test("A multiplicação de 10 X 10 é igual a 100", () => {
    expect(fnMultiplicar(10, 10)).toBe(100)
})

test("A multiplicação de -89 X 9 é -801", () => {
    expect(fnMultiplicar(-89, 9)).toBe(-801)
})

test("A multiplicação de 2 X 1000 é igual a 2000", () => {
    expect(fnMultiplicar(2, 1000)).toBe(2000)
})

test("A multiplicação de -9 X 2 é igual a 18", () => {
    expect(fnMultiplicar(-9, 2)).toBe(-18)
})