function fnDividir(num1, num2){
    return num1 / num2;
}

module.exports = fnDividir;